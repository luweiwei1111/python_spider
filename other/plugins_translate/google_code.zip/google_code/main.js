// 导入translate
var trans= require('./translate.js');

// 调用翻译结果
trans.gettrans('你好')